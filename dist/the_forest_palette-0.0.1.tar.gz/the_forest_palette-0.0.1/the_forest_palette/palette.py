# mycolors/palette.py

CUSTOM_PALETTE = {
    "deepestgreen": "#080C07",
    "richdarkgreen": "#284021",
    "mintyforest": "#658F59",
    "softapple": "#9FD390",
    "cooldarkgreen": "#405947",
    "brightmint": "#B7E6D4",
    "softmint": "#8EB8A8",
    "curiousapple": "#76BE5E",
    "ashmint": "#CAE4DA"
}


