# mycolors/palette.py

CUSTOM_PALETTE = {
    "deepestgreen": "#080C07",
    "richdarkgreen": "#284021",
    "cooldarkgreen": "#405947",
    "curiousapple": "#76BE5E",
    "mintyforest": "#658F59",
    "softmint": "#8EB8A8",
    "softapple": "#9FD390",
    "brightmint": "#B7E6D4",
    "ashmint": "#CAE4DA"
}


